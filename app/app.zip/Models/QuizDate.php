<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuizDate extends Model
{
    protected $table = "quiz_date";
    public $incrementing = false;
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassRoom extends Model
{
    protected $table = "class_room";
    public $incrementing = false;
    // protected $primaryKey = "id";
    // protected $guarded = ["*"];
}
